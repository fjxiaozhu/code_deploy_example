#!/bin/bash

# Here is where you'd want to stop your http daemon. For example:
#service httpd stop
#exit $?

# In this case, since it's just a placeholder, we don't need to do anything.
exit 0
